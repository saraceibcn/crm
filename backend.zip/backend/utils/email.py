import smtplib
from email.mime.text import MIMEText
from flask import current_app


def enviar_correo_html(destino: str, asunto: str, cuerpo_html: str):
    msg = MIMEText(cuerpo_html, "html", "utf-8")
    msg["Subject"] = asunto
    msg["From"] = current_app.config["MAIL_DEFAULT_SENDER"]
    msg["To"] = destino

    smtp_host = current_app.config["MAIL_SERVER"]
    smtp_port = current_app.config["MAIL_PORT"]
    smtp_user = current_app.config["MAIL_USERNAME"]
    smtp_pass = current_app.config["MAIL_PASSWORD"]

    server = smtplib.SMTP(smtp_host, smtp_port)
    server.starttls()
    server.login(smtp_user, smtp_pass)
    server.send_message(msg)
    server.quit()
