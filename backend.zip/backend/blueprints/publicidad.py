from flask import Blueprint, request, jsonify, current_app
from backend.utils.db import get_connection
from backend.utils.tokens import generar_token_unsubscribe, verificar_token_unsubscribe
from backend.utils.email import enviar_correo_html

publicidad_bp = Blueprint("publicidad_bp", __name__, url_prefix="/api/publicidad")


def ejecutar_query(query, params=None):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(query, params or ())
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows


@publicidad_bp.route("/enviar", methods=["POST"])
def enviar_publicidad():
    data = request.get_json() or {}
    asunto = data.get("asunto")
    mensaje_html = data.get("mensaje")

    if not asunto or not mensaje_html:
        return jsonify({"error": "Faltan 'asunto' o 'mensaje'"}), 400

    usuarios = ejecutar_query("""
        SELECT idUsuario, nombre, email
        FROM usuario_sistema
        WHERE publicidad = 1
    """)

    base_url = current_app.config["PUBLIC_BASE_URL"].rstrip("/")

    enviados = 0
    for u in usuarios:
        token = generar_token_unsubscribe(u["idUsuario"])
        enlace_unsubscribe = f"{base_url}/api/publicidad/unsubscribe?token={token}"

        cuerpo = f"""
            <p>Hola {u['nombre']},</p>
            {mensaje_html}
            <hr>
            <p style="font-size:12px;color:gray">
                <a href="{enlace_unsubscribe}">Darte de baja</a>
            </p>
        """

        enviar_correo_html(u["email"], asunto, cuerpo)
        enviados += 1

    return jsonify({"status": "ok", "enviados": enviados})


@publicidad_bp.route("/unsubscribe", methods=["GET"])
def unsubscribe():
    token = request.args.get("token", "")

    user_id, error = verificar_token_unsubscribe(token)

    if error:
        return "<h2>Enlace no válido o caducado</h2>", 400

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE usuario_sistema SET publicidad = 0 WHERE idUsuario = %s", (user_id,))
    conn.commit()
    cursor.close()
    conn.close()

    return """
        <h2>Te has dado de baja correctamente</h2>
        <p>No recibirás más publicidad.</p>
    """
